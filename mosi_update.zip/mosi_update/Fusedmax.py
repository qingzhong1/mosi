"""
An implementation of sparsemax (Martins & Astudillo, 2016). See
:cite:`DBLP:journals/corr/MartinsA16` for detailed description.

By Ben Peters and Vlad Niculae
"""
import warnings
import torch
from torch.autograd import Function
import torch.nn as nn
import torchsparseattn as sparse
from torch import autograd as ta
from torchsparseattn.fused import prox_tv1d, _inplace_fused_prox_jv
alpha=0.9
def project(x):
    x_np = x.detach().numpy().copy()
    prox_tv1d(x_np,alpha)
    y_hat = torch.from_numpy(x_np)
    return y_hat
def project_jv(dout, y_hat):
    dout = dout.clone()
    _inplace_fused_prox_jv(y_hat.detach().numpy(), dout.numpy())
    return dout
class _BaseBatchProjection(ta.Function):
    """Applies a sample-wise normalizing projection over a batch."""

    @staticmethod
    def forward(self, x, lengths=None):

        requires_squeeze = False
        if x.dim() == 1:
            x = x.unsqueeze(0)
            requires_squeeze = True

        n_samples, max_dim = x.size()

        has_lengths = True
        if lengths is None:
            has_lengths = False
            lengths = [max_dim] * n_samples

        y_star = x.new()
        y_star.resize_as_(x)
        y_star.zero_()

        for i in range(n_samples):
            y_star[i, :lengths[i]] = project(x[i, :lengths[i]])

        if requires_squeeze:
            y_star = y_star.squeeze()

        self.mark_non_differentiable(y_star)
        if has_lengths:
            self.mark_non_differentiable(lengths)
            self.save_for_backward(y_star, lengths)
        else:
            self.save_for_backward(y_star)

        return y_star

    @staticmethod
    def backward(self, dout):

        if not self.needs_input_grad[0]:
            return None

        if len(self.needs_input_grad) > 1 and self.needs_input_grad[1]:
            raise ValueError("Cannot differentiate {} w.r.t. the "
                             "sequence lengths".format(self.__name__))

        saved = self.saved_tensors
        if len(saved) == 2:
            y_star, lengths = saved
        else:
            y_star, = saved
            lengths = None

        requires_squeeze = False
        if y_star.dim() == 1:
            y_star = y_star.unsqueeze(0)
            dout = dout.unsqueeze(0)
            requires_squeeze = True

        n_samples, max_dim = y_star.size()
        din = dout.new()
        din.resize_as_(y_star)
        din.zero_()

        if lengths is None:
            lengths = [max_dim] * n_samples

        for i in range(n_samples):
            din[i, :lengths[i]] = project_jv(dout[i, :lengths[i]],
                                                  y_star[i, :lengths[i]])

        if requires_squeeze:
            din = din.squeeze()

        return din, None

fused=_BaseBatchProjection.apply
"""
An implementation of sparsemax (Martins & Astudillo, 2016). See
:cite:`DBLP:journals/corr/MartinsA16` for detailed description.

By Ben Peters and Vlad Niculae
"""
import warnings
import torch
from torch.autograd import Function
import torch.nn as nn
import torchsparseattn as sparse


def _make_ix_like(input, dim=0):
    d = input.size(dim)
    rho = torch.arange(1, d + 1, device=input.device, dtype=input.dtype)
    view = [1] * input.dim()
    view[0] = -1
    return rho.view(view).transpose(0, dim)


def _threshold_and_support(input, dim=0):
    """Sparsemax building block: compute the threshold

    Args:
        input: any dimension
        dim: dimension along which to apply the sparsemax

    Returns:
        the threshold value
    """

    input_srt, _ = torch.sort(input, descending=True, dim=dim)
    input_cumsum = input_srt.cumsum(dim) - 1
    rhos = _make_ix_like(input, dim)
    support = rhos * input_srt > input_cumsum

    support_size = support.sum(dim=dim).unsqueeze(dim)
    tau = input_cumsum.gather(dim, support_size - 1)
    tau /= support_size.to(input.dtype)
    return tau, support_size


class SparsemaxFunction(Function):

    @staticmethod
    def forward(ctx, input, dim=0):
        """sparsemax: normalizing sparse transform (a la softmax)

        Parameters:
            input (Tensor): any shape
            dim: dimension along which to apply sparsemax

        Returns:
            output (Tensor): same shape as input
        """
        ctx.dim = dim
        max_val, _ = input.max(dim=dim, keepdim=True)
        input -= max_val  # same numerical stability trick as for softmax
        tau, supp_size = _threshold_and_support(input, dim=dim)
        output = torch.clamp(input - tau, min=0)
        ctx.save_for_backward(supp_size, output)
        return output

    @staticmethod
    def backward(ctx, grad_output):
        supp_size, output = ctx.saved_tensors
        dim = ctx.dim
        grad_input = grad_output.clone()
        grad_input[output == 0] = 0

        v_hat = grad_input.sum(dim=dim) / supp_size.to(output.dtype).squeeze()
        v_hat = v_hat.unsqueeze(dim)
        grad_input = torch.where(output != 0, grad_input - v_hat, grad_input)
        return grad_input, None
sparsemax = SparsemaxFunction.apply
class Fusedmax(nn.Module):

    """ Fusedmax clusters vectors into contiguous clusters of equal weight

    Vlad Niculae and Mathieu Blondel.
    A Regularized Framework for Sparse and Structured Neural Attention
    In: Proceedings of NIPS, 2017. https://arxiv.org/abs/1705.07704"""

    def __init__(self,alpha=1):
        self.fused = sparse.FusedProxFunction(alpha=alpha)
        super(Fusedmax, self).__init__()
    
    def forward(self,input):
        
        original_size = input.shape
        original_device = input.device
        
        flat = input.view(-1,input.size(-1)).cpu() # convert n-D tensor to 2-D
        lengths = torch.tensor([flat.size(-1)]*flat.size(0)).to(original_device)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore") # ignore warning about deprecated support for non-static autograd function
            result = fused(flat,lengths) # perform

        result = result.view(*original_size).to(original_device) # return to original shape and device
        return sparsemax(result,-1)

class Nucleusmax(nn.Module):
    def __init__(self,alpha=0.9):
        super(Nucleusmax, self).__init__()
        self.alpha = alpha
    def forward(self,input):
        return nucleusmax_function(input,self.alpha)
def nucleusmax_function(nums,alpha=0.9):
    nums=torch.softmax(nums, dim=1)
    input=torch.sort(nums, dim=1, descending=True)
    value=input.values
    index=input.indices
    value=torch.cumsum(value, dim=1)
    value_index=value<alpha
    index=torch.where(value_index==True, index, -1)
    index=index.cpu().data.numpy().tolist()
    mask_all=[]
    for i in range(nums.shape[0]):
        mask=torch.full((nums[i].shape), float('-inf'))
        mask_index=[i for i in index[i] if i!=-1]
        mask[mask_index]=0
        mask_all.append(mask)
    nums=nums+torch.stack(mask_all).to(nums.device)
    nums=torch.softmax(nums, dim=1)
    return nums