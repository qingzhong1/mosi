# import torch
# from sparsemax import Sparsemax
# loss=Sparsemax()
# input=torch.rand(10,5)
# print(loss(input))
# breakpoint()
# breakpoint()



# from Fusedmax import Fusedmax
# import torch
# loss=Fusedmax()
# input=torch.randn(size=(10,5))
# print(loss(input))
import torch
nums=torch.randn(size=(10,5))
nums=torch.softmax(nums, dim=1)
input=torch.sort(nums, dim=1, descending=True)
value=input.values
index=input.indices
value=torch.cumsum(value, dim=1)
value_index=value<0.9
index=torch.where(value_index==True, index, -1)
index=index.numpy().tolist()
mask_all=[]
for i in range(nums.shape[0]):
    mask=torch.full((nums[i].shape), float('-inf'))
    mask_index=[i for i in index[i] if i!=-1]
    mask[mask_index]=0
    mask_all.append(mask)
nums=nums+torch.stack(mask_all)
nums=torch.softmax(nums, dim=1)


# from torch.autograd import Function
# class Exp(Function):
#     @staticmethod
#     def forward(self, i):
#         result = i.exp()
#         self.save_for_backward(result)
#         return result

#     @staticmethod
#     def backward(self, grad_output):
#         result, = self.saved_tensors
#         return grad_output * result

# # Use it by calling the apply method:
# output = Exp.apply(input)
# # print(loss.apply(input))

# # class Exp(Function):
# #     @staticmethod
# #     def forward(ctx, i):
# #         result = i.exp()
# #         ctx.save_for_backward(result)
# #         return result
# #     @staticmethod
# #     def backward(ctx, grad_output):
# #         result, = ctx.saved_tensors
# #         return grad_output * result
# # # Use it by calling the apply method:
# # output = Exp.apply(input)